"use strict";

var util          = require('util');
var request       = require('request');
var fs            = require('fs');
var moment        = require('moment');
var async         = require('async');
var sldutil       = require('../../sldutil.js');
var agt           = require('../../agent.js');
var agtLongterm   = require('../../agent_longterm.js');

var objectPlugin    = '../plugin.js';
if (require.cache[require.resolve(objectPlugin)])
	delete require.cache[require.resolve(objectPlugin)];
var Plugin = require(objectPlugin);

// exports
exports.getPluginInfo   = getPluginInfo;
exports.plugin_module   = plugin_module;

// -------------------------------------------------
// getPluginInfo
// Do not modify the structure of this method
// -------------------------------------------------
function getPluginInfo() {
  return { pluginName           : 'add_vm_vmware_cluster_drs_sysload',
           pluginType           : 'vm_provisioning',
           pluginDescription    : 'SYSLOAD ANALYST AUTOMATION PLUGIN "ADD_VM_VMWARE_CLUSTER_DRS"',
           pluginVersion        : 10,
           pluginTemplateParams : 'username=aso&password=sysload&target_agent_list=VMCLUSTER;VMSDMINF03;TECHNO&request_vcpu_no=1&request_memory_gb=1&request_storage_gb=0,06&target_datastore_list=CSErp-1,WlaErp-1,TipProd-1&target_reserve_host_no=0&target_reserve_cpu_ratio=0&target_reserve_memory_ratio=10&target_reserve_storage_ratio=0&analysis_duration=24&analysis_duration_unit=day&analysis_duration_step=1%20hour&trace_level=1&outputformat=html&metric_col=onlyvalues'
         };
}

/*
INTERNAL INFORMATION ABOUT THIS SCRIPT
---

Values for "trace_level" used in this script:
- 0: No trace
- 1: Includes traces that explain why the answer is Nogo
- 2: Includes traces that explain the analysis, even if the anwser is Go
- 3: Includes traces that are general, even information that is not directly useful to the analytics done by the Plugin
*/ 

// -------------------------------------------------
// plugin_module
// -------------------------------------------------
function plugin_module (genericParams, callback) {

    //---------------------------------
    // Create and init oPlugin object
  var oPlugin = new Plugin ();

  oPlugin.init (genericParams,
                callback, 
                onInit);       // stage 1 (the function is defined below)
                
} // plugin_module


// -------------------------------------------------
// onInit
// -------------------------------------------------
function onInit (oPlugin) {

	// Retrieve all URL parameters  and set default values if they are not set in the URL

	// Information about the Sysload Agent for VMware Custer agent to request
	// Agent name, no default value
	oPlugin.addToPluginParam_FromUrlParam ('target_agent_name', '', "str");
	// Agent Instance name - In most cases, equal to the VMware cluster, no default value
	oPlugin.addToPluginParam_FromUrlParam ('target_agent_instance_name', '', "str");
	
	// Datastores that may be used for storing VM data
	oPlugin.addToPluginParam_FromUrlParam ('target_datastore_list', '', "str");
	
	// Number of hosts used for quantifying the desired capacity reserves for CPU and memory - VMware "HA Failover Level"
	oPlugin.addToPluginParam_FromUrlParam ('target_reserve_host_no', 0, "int");
	//var target_reserve_host_no = oPlugin.getPluginParam ('target_reserve_host_no');

	// VMware "CpuFailoverResourcesPercentage"
	oPlugin.addToPluginParam_FromUrlParam ('target_reserve_cpu_ratio', 0, "int");
	// VMware "MemoryFailoverResourcesPercentage"
	oPlugin.addToPluginParam_FromUrlParam ('target_reserve_memory_ratio', 0, "int");
	// 
	oPlugin.addToPluginParam_FromUrlParam ('target_reserve_storage_ratio', 0, "int");

	// Requested number of vCPU for the VM
	oPlugin.addToPluginParam_FromUrlParam ('request_vcpu_no', 4, "int");
	// Requested memory capacity for the VM, in GB, default 16 
	oPlugin.addToPluginParam_FromUrlParam ('request_memory_gb', 16, "float");
	// Requested storage capacity for the VM, in GB, default 50
	oPlugin.addToPluginParam_FromUrlParam ('request_storage_gb', 50, "float");

	// Filters for details in the HTML output - For host demo, no longer used
	//oPlugin.addToPluginParam_FromUrlParam ('hostmetric_col', 'undef');   // undef | all | onlyvalues
	//oPlugin.addToPluginParam_FromUrlParam ('hostmetric_row', 'onlyuseful');  // undef all | onlyuseful
	
	// 9 Feb 2016, DES - The test does not seem to work , no mesg displayed and no return done --> PWN because of the comparaison to undefined
	var target_datastore_list = oPlugin.getPluginParam ('target_datastore_list');
	if(target_datastore_list === '') {  // PWN old -> undefined  instead of ''
		var message = "Error - Could not get value of plugin parameter 'target_datastore_list' or value is null";
		if (oPlugin.getTraceLevel () >= 1) {
			var oPluginFeedback = {comment    : "",
		                           oExtraInfo : {} 
		                          };
			oPluginFeedback.oExtraInfo.observations = [];
			oPluginFeedback.oExtraInfo.log = [];
			debug(oPlugin, message, 1, oPluginFeedback);
		}
	    oPlugin.sendResponse (0,         // answer, 
	                          1,         // return_code, 
	                          message,   // comment, 
	                          null,      // oMetricsData
	                          null,      // bAddGlobalMetricsDataArraysToSend,
	                          null);     // retrievedMetricWithInstDataArraysToSend,
		return;
	}
	
	var message;
	message = "===========================================================================";
	debug(oPlugin, message, 1, null);
	
	// Prepare description for HTML output
	// A new param "htmlRequestDescriptionArray" in Plugin parameters
	// Leave with a space instead of null to avoid warning message in console
	var htmlRequestDescriptionArray = [];
	
	if (oPlugin.getOutputFormat () === 'html') {
		htmlRequestDescriptionArray.push ('datastore_list=' + oPlugin.getPluginParam ('target_datastore_list'));
		htmlRequestDescriptionArray.push ('storage=' + oPlugin.getPluginParam ('request_storage_gb') + ' GB' +
								 ', cpu='     + oPlugin.getPluginParam ('request_vcpu_no')    +
								 ', memory='  + oPlugin.getPluginParam ('request_memory_gb')  + ' GB');
	}
	
	oPlugin.addToPluginParam_NewProperty ('htmlRequestDescriptionArray', htmlRequestDescriptionArray);

	var target_datastore_list = oPlugin.getPluginParam ('target_datastore_list');
	var bCheckDatastores = true;
	if(target_datastore_list === '') {
		bCheckDatastores = false;      // PWN old value was null, if the variable is defined it should be either 'true' or 'false' 
	}

	message = "Value of bCheckDatastores is '" + bCheckDatastores + "'";
	debug(oPlugin, message, 2, null);
	
    //-----------------------------------------------------------------------
    // Select instances to retrieve then 
    // continue in the function 'onGetMetricInstances' (stage 2)
    var arrDemandedInstances = [];
    if (bCheckDatastores) {
	    arrDemandedInstances = [ "Host-Specific"
	                            ,"Datastore-Specific"
	                            /*
	                            ,"Resourcepool-Specific"
	                            ,"VM-Specific"
	                            */
	                            ];
    } else {

	    arrDemandedInstances = [ "Host-Specific"
	                            ];
    }
    oPlugin.request_ForMetricInstances (arrDemandedInstances,
                                        onGetMetricInstances); // stage 2 (the function is defined below)

} // end onInit

// -------------------------------------------------
// onGetMetricInstances
//
// The function to make some actions on retrieved metric instances
// and to select a list of metrics to retrive their data
//
// -------------------------------------------------
function onGetMetricInstances (oPlugin, oMetricInstances) {
	
	var message;
	var arrInstances_Host         = oPlugin.get_ArrayOfInstances (oMetricInstances, "Host-Specific");
	var arrInstances_DataStore    = oPlugin.get_ArrayOfInstances (oMetricInstances, "Datastore-Specific");


	// Displaying info, that may be useful when debugging
	message = 'Number of Hosts found in the cluster is arrInstances_Host.length = ' + arrInstances_Host.length;
	debug(oPlugin, message, 3, null);
	
	if (arrInstances_Host.length > 0) {
		message = 'First Host found in the cluster is arrInstances_Host[0] = ' + arrInstances_Host[0];
		debug(oPlugin, message, 3, null);
	}
	
	message = 'Number of dastastores found in the cluster is arrInstances_DataStore.length = ' + arrInstances_DataStore.length;
	debug(oPlugin, message, 3, null);
	
	if (arrInstances_DataStore.length > 0) {
		message = 'First Datastore found in the cluster is  arrInstances_DataStore[0] = ' + arrInstances_DataStore[0];
		debug(oPlugin, message, 3, null);
	}
	
	// Verify that the given datastores are actually in the cluster
	var target_datastore_list = oPlugin.getPluginParam ('target_datastore_list');
	message = "The given list of target datastores is '" + target_datastore_list + "'";
	debug(oPlugin, message, 2, null);
	
	var arrTargetDatastoresInstanceNames = [];
	
	if(target_datastore_list === "null") {
		message = "No datastore given, bypassing check if present in the Sysload Agent";
		debug(oPlugin, message, 2, null);
	}
	else {
		// Verification should be done in a function
		var bDatastoreFound = false;
		var targetDatastore = "";
		arrTargetDatastoresInstanceNames = target_datastore_list.split(",");
		// if null ...
		// Verify each datasore in the array acually exists in the cluster
		for(targetDatastore of arrTargetDatastoresInstanceNames) {
			
			bDatastoreFound = oPlugin.checkIfDomainInstanceFound (arrInstances_DataStore, targetDatastore);
			if(bDatastoreFound) {
				message = "The datastore '" + targetDatastore + "' has been found in the cluster";
				debug(oPlugin, message, 2, null);
			}
			else {
				var strAgentId = oPlugin.getAgentId ();
				message = "The target datastore '" + targetDatastore + "' could not be found in the cluster on '"+strAgentId+"'";
				debug(oPlugin, message, 1, null);
				var comment = sldutil.clone (message);
				
				// Build the list of datastores found in the cluster, for debugging
				var list = "";
				for(var i = 0; i < arrInstances_DataStore.length; i++) {
					list = list + arrInstances_DataStore[i] + ",";
				}
				
					// PWN modification
				if (arrInstances_DataStore.length === 0) {
					message += "; list of datastore is empty";
					comment += "; list of datastore is empty";
				}
				else
					message += "list of datastore is: " + "'" + list + "'";
				debug(oPlugin, message, 3, null);

				  //--------------------
				  // customDataArraysToSend 
				  //--------------------
			    var customDataArraysToSend;
				if (arrInstances_DataStore.length !== 0) {
				    var label = "The list of datastores found in the cluster is: ";
					customDataArraysToSend = {};
					  // arrDataStore_Instances 
					customDataArraysToSend[label] = 
					                   oPlugin.getArrayOfMetricInstancesToSend (oMetricInstances, "Datastore-Specific");
				}

			    oPlugin.sendResponse (0,         // answer, 
			                          1,         // return_code, 
			                          comment,   // comment, 
			                          null,      // oMetricsData
			                          null,      // bAddGlobalMetricsDataArraysToSend,
			                          null,      // retrievedMetricWithInstDataArraysToSend,
			                          customDataArraysToSend); // customDataArraysToSend
				
				return;
			}
		}
	}	
	    //------------------------------------------------
        // Array of Sysload metrics to retrieve from Sysload Agent
	var arrVMwareClusterMetricsToRetrieve = [  // Metrics per host
	                                          {metric: "Host-Specific-pc_uptime",            calctype: "avg"}
	                                         ,{metric: "Host-Specific-pc_maintenancemode",   calctype: "avg"}
	                                         ,{metric: "Host-Specific-CPUcapacity",          calctype: "avg"}
	                                         ,{metric: "Host-Specific-CPUspeed",             calctype: "avg"}
	                                         ,{metric: "Host-Specific-CPUused",              calctype: "avg"}
	                                         ,{metric: "Host-Specific-CPUreserved",          calctype: "avg"}
	                                      // ,{metric: "Host-Specific-CPUs",                 calctype: "avg"}
	                                         ,{metric: "Host-Specific-memorycapacity" ,      calctype: "avg"}
	                                         ,{metric: "Host-Specific-memoryconsumed",       calctype: "avg"}
	                                         ,{metric: "Host-Specific-memoryreserved",       calctype: "avg"}

                                                // Metrics per datastore
	                                         ,{metric: "Datastore-Specific-storagefree",     calctype: "avg"}
	                                         ,{metric: "Datastore-Specific-storagecapacity", calctype: "avg"}

	                                            // Overall metrics
	                                         ,{metric: "CPU-Overall-CPUcapacity",            calctype: "avg"}
	                                         ,{metric: "CPU-Overall-CPUused",                calctype: "avg"}
	                                         ,{metric: "Memory-Overall-memorycapacity",      calctype: "avg"}
	                                         ,{metric: "Memory-Overall-memoryconsumed",      calctype: "avg"}

	                                        ];

	// Array of hosts for which data shall be retrieved
	var arrClusterHostInstanceNames = [];
	// Defines whether the Plugin is being run in test mode or in production - Can gain time in test mode if there are many hosts in the cluster
	var bTestRun = false;

	if(bTestRun) {
		var oPluginFeedback = {comment    : "",
	                           oExtraInfo : {} 
	                          };
		oPluginFeedback.oExtraInfo.observations = [];
		oPluginFeedback.oExtraInfo.log = [];

		// Work with a partial list of hosts in the cluster (to gain time when developping and testing)
		message = "WORKING WITH A PARTIAL HOST LIST - SHOULD NOT BE LIKE THIS IN PRODUCTION";
		debug(oPlugin, message, 1, oPluginFeedback);
		addToPluginFeedbackObservations(message, oPluginFeedback);
		arrClusterHostInstanceNames.push (arrInstances_Host [0]);
		arrClusterHostInstanceNames.push (arrInstances_Host [1]);
	}
	else {
		// Work with the full list of hosts in the cluster (it should be like this in production)
		arrClusterHostInstanceNames = arrInstances_Host;
	}
	
	message = "Requesting metric values to Sysload Agent...";
	debug(oPlugin, message, 2, null);
	
	    //---------------------------------------------------------
	    // define arrays of instances to retrieve demanded metrics
	  var oArraysOfInstances = { "Host-Specific"         : arrClusterHostInstanceNames
	                            ,"Datastore-Specific"    : arrTargetDatastoresInstanceNames
	                            /*
	                            ,"Resourcepool-Specific" : arrVmCluster_ResourcePools
	                            ,"VM-Specific"           : arrVmCluster_Vms
	                            */
	                           };
	  oPlugin.request_ForMetricData ( arrVMwareClusterMetricsToRetrieve,
	                                  oArraysOfInstances,
	                                  onGetMetricData);   // stage 3 (the function is defined below)

} // onGetMetricInstances   

// -------------------------------------------------
// onGetMetricData
//
// At this stage all data are retrieved.
// This function implement the main part of the customized plugin
//
// -------------------------------------------------
function onGetMetricData (oPlugin, oMetricsData) {
	
	var message = "";
	var answer = 0;
	var returnCode = 1;
	var comment = "";
	
	message = "Metric values obtained from Agent";
	debug(oPlugin, message, 2, null);

	var oPluginFeedback = {comment    : "",     // PWN modified because of best practices
                           oExtraInfo : {} 
                          };
	oPluginFeedback.oExtraInfo.observations = [];
	oPluginFeedback.oExtraInfo.log = [];

	// Do the overall check for CPU and memory
	var stepAnswerHAFailoverLevel = checkHAFailoverLevel(oPlugin, oMetricsData, oPluginFeedback);

	// Check if at least one datastore is OK
	var stepAnswerDatastores = checkDatastores(oPlugin, oMetricsData, oPluginFeedback);

	// Check if a least one host is OK
	var stepAnswerHosts  = checkHosts(oPlugin, oMetricsData, oPluginFeedback);

	// If one of the checks returned in error
	if ((stepAnswerHAFailoverLevel === -1) || (stepAnswerDatastores === -1) || (stepAnswerHosts === -1)) {
		message = "At least one step in the overhole check returned in error";
		debug(oPlugin, message, 2, null);
		// The whole shall return in erros
		returnCode = 1;
		answer = 0;
	}
	else {
		message = "None of the steps returned in error";
		debug(oPlugin, message, 2, null);

		// None of the checks returned in error
		returnCode = 0;
		// If all of the checks returned a Go, the the whole shall return a Go
		if ((stepAnswerHAFailoverLevel === 1) && (stepAnswerDatastores === 1) && (stepAnswerHosts === 1)) {
			message = "All of the steps returned Go";
			debug(oPlugin, message, 2, null);
			answer = 1;
		}
		else {
			// At least one check returned a Nogo, the whole shall return a Nogo
			message = "At least one the step returned Nogo";
			debug(oPlugin, message, 2, null);
			answer = 0;
		}
	}
		
	comment = oPluginFeedback.comment; //+ " --- Analysis observervations: " + oExtraInfo.observations;

	    //----------------------------
	    // sendResponse
	var retrievedMetricWithInstDataArraysToSend = ["Host-Specific", "Datastore-Specific", "Resourcepool-Specific"/*, "VM-Specific"*/];
	oPlugin.sendResponse (answer,                                  // answer, 
	                      returnCode,                              // return_code, 
	                      comment,                                 // comment, 
	                      oMetricsData,                            // oMetricsData
	                            
	                      true,                                    // bAddGlobalMetricsDataArraysToSend,
	                      retrievedMetricWithInstDataArraysToSend, // retrievedMetricWithInstDataArraysToSend,

	                      oPluginFeedback.oExtraInfo);             // customDataArraysToSend
	
	message = "Plugin terminated successfully";
	debug(oPlugin, message, 1, oPluginFeedback);
	
	message = "===========================================================================";
	debug(oPlugin, message, 1, oPluginFeedback);

} // end onGetMetricData()  

// -------------------------------------------------
// Internal function for this plugin
// Check if at least one host is OK for CPU and memory
// Return 1 if the answer is OK, 0 otherwise
// -------------------------------------------------
function checkHosts(oPlugin, oMetricsData, oPluginFeedback) {
	
	var message = "";
	var bAtLeastOneHostOkForNewVm = false;

	var request_vcpu_no = oPlugin.getPluginParam ('request_vcpu_no');
	var request_memory_gb = oPlugin.getPluginParam ('request_memory_gb');
	var target_reserve_cpu_ratio = oPlugin.getPluginParam ('target_reserve_cpu_ratio');
	var target_reserve_memory_ratio = oPlugin.getPluginParam ('target_reserve_memory_ratio');
	
	var numHosts = oPlugin.get_MetricInst_Count (oMetricsData, "Host-Specific");

	// Array of candidate hosts for running the VM
	var candidateHosts = new Array;
	
	message = "Number of analyzed hosts in the cluster is '" + numHosts + "'";
	debug(oPlugin, message, 2, oPluginFeedback);
	addToPluginFeedbackObservations(message, oPluginFeedback);
	
	// check if exists at least one vmHost for vm provisionning
	for (var idxHost = 0; idxHost < numHosts ; idxHost++) {
		var hostName = oPlugin.get_MetricInst_Name (oMetricsData, "Host-Specific", idxHost);

		message = "Starting to process host '" + hostName + "'";
		debug(oPlugin, message, 2, oPluginFeedback);
		
		var oUptime = {};
		var oMaintenanceMode = {};

		var oCpuNumber = {};
		var oCpuUsed_mhz = {};
		var oCpuReserved_mhz = {};
		var oCpuFrequency_mghz = {};
		var oCpuCapacity_mhz = {};

		//var oMemoryFreeOrig_mb = {};
		var oMemoryUsed_mb = {};
		var oMemoryReserved_mb = {};
		var oMemoryCapacity_mb = {};

		// Check the percent of uptime
		oUptime.value  = oPlugin.get_MetricInst_Data (oMetricsData, idxHost, "Host-Specific-pc_uptime", "avg", "valueLast");
		oUptime.pcinfo = oPlugin.get_MetricInst_Data (oMetricsData, idxHost, "Host-Specific-pc_uptime", "avg", "infoLast");

		message = "Host '" + hostName + "', uptime =  " + oUptime.value + " (%)'";
		debug(oPlugin, message, 2, oPluginFeedback);

		if (oUptime.value !== 100) {
			message = "Host '" + hostName + "' has not always been up during the last few minutes - Ignoring it";
			debug(oPlugin, message, 1, oPluginFeedback);
			addToPluginFeedbackObservations(message, oPluginFeedback);
			continue;
		}

		// Check the percent of the maintenancemode
		oMaintenanceMode.value  = oPlugin.get_MetricInst_Data (oMetricsData, idxHost, "Host-Specific-pc_maintenancemode", "avg", "valueLast");
		oMaintenanceMode.pcinfo = oPlugin.get_MetricInst_Data (oMetricsData, idxHost, "Host-Specific-pc_maintenancemode", "avg", "infoLast");

		message = "Host '" + hostName + "', Maintenance mode =  " + oMaintenanceMode.value + " (%)'";
		debug(oPlugin, message, 2, oPluginFeedback);

		if (oMaintenanceMode.value !== 0) {
			message = "Host '" + hostName + "' has been in maintenance mode during the last few minutes - Ignoring it";
			debug(oPlugin, message, 1, oPluginFeedback);
			addToPluginFeedbackObservations(message, oPluginFeedback);
			continue;
		}
		
		// Prepare variables with oMetricsData metric values, the object containting the metric values obtained from the Sysload Agent
		
		oCpuUsed_mhz.value  = oPlugin.get_MetricInst_Data (oMetricsData, idxHost, "Host-Specific-CPUused", "avg", "valueMax");
		oCpuUsed_mhz.pcinfo = oPlugin.get_MetricInst_Data (oMetricsData, idxHost, "Host-Specific-CPUused", "avg", "infoMax");
		var hostCpuUsedMhz = parseFloat(oCpuUsed_mhz.value);
		
		oCpuReserved_mhz.value  = oPlugin.get_MetricInst_Data (oMetricsData, idxHost, "Host-Specific-CPUreserved", "avg", "valueLast");
		oCpuReserved_mhz.pcinfo = oPlugin.get_MetricInst_Data (oMetricsData, idxHost, "Host-Specific-CPUreserved", "avg", "infoLast");
		var hostCpuReservedMhz = parseFloat(oCpuReserved_mhz.value);

		oCpuFrequency_mghz.value  = oPlugin.get_MetricInst_Data (oMetricsData, idxHost, "Host-Specific-CPUspeed", "avg", "valueLast");
		oCpuFrequency_mghz.pcinfo = oPlugin.get_MetricInst_Data (oMetricsData, idxHost, "Host-Specific-CPUspeed", "avg", "infoLast");
		var hostCpuFrequencyMhz = parseFloat(oCpuFrequency_mghz.value);

		oCpuCapacity_mhz.value  = oPlugin.get_MetricInst_Data (oMetricsData, idxHost, "Host-Specific-CPUcapacity", "avg", "valueLast");
		oCpuCapacity_mhz.pcinfo = oPlugin.get_MetricInst_Data (oMetricsData, idxHost, "Host-Specific-CPUcapacity", "avg", "infoLast");
		var hostCpuCapacityMhz = parseFloat(oCpuCapacity_mhz.value);

		oMemoryUsed_mb.value  = oPlugin.get_MetricInst_Data (oMetricsData, idxHost, "Host-Specific-memoryconsumed", "avg", "valueMax");
		oMemoryUsed_mb.pcinfo = oPlugin.get_MetricInst_Data (oMetricsData, idxHost, "Host-Specific-memoryconsumed", "avg", "infoMax");
		var hostMemoryUsedMb = parseFloat(oMemoryUsed_mb.value);

		oMemoryReserved_mb.value  = oPlugin.get_MetricInst_Data (oMetricsData, idxHost, "Host-Specific-memoryreserved", "avg", "valueLast");
		oMemoryReserved_mb.pcinfo = oPlugin.get_MetricInst_Data (oMetricsData, idxHost, "Host-Specific-memoryreserved", "avg", "infoLast");
		var hostMemoryReservedMb = parseFloat(oMemoryReserved_mb.value);

		oMemoryCapacity_mb.value  = oPlugin.get_MetricInst_Data (oMetricsData, idxHost, "Host-Specific-memorycapacity", "avg", "valueLast");
		oMemoryCapacity_mb.pcinfo = oPlugin.get_MetricInst_Data (oMetricsData, idxHost, "Host-Specific-memorycapacity", "avg", "infoLast");
		var hostMemoryCapacityMb = parseFloat(oMemoryCapacity_mb.value);
		
		// Take into account the CPU reservations as if they were consumed
		var hostCpuConsideredUsedMhz;
		if (hostCpuUsedMhz > hostCpuReservedMhz) {
			hostCpuConsideredUsedMhz = hostCpuUsedMhz;
		}
		else {
			hostCpuConsideredUsedMhz = hostCpuReservedMhz;
		} 

		message = "Host '" + hostName + "', hostCpuCapacityMhz = '" + hostCpuCapacityMhz + "'";
		debug(oPlugin, message, 2, oPluginFeedback);
		addToPluginFeedbackObservations(message, oPluginFeedback);

		message = "Host '" + hostName + "', hostCpuUsedMhz = '" + hostCpuUsedMhz + "'";
		debug(oPlugin, message, 2, oPluginFeedback);
		addToPluginFeedbackObservations(message, oPluginFeedback);
		
		message = "Host '" + hostName + "', hostCpuReservedMhz = '" + hostCpuReservedMhz + "'";
		debug(oPlugin, message, 2, oPluginFeedback);
		addToPluginFeedbackObservations(message, oPluginFeedback);
		
		message = "Host '" + hostName + "', hostCpuConsideredUsedMhz = '" + hostCpuConsideredUsedMhz + "'";
		debug(oPlugin, message, 2, oPluginFeedback);
		addToPluginFeedbackObservations(message, oPluginFeedback);
		
		var hostCpuFreeMhz = 0;

		hostCpuFreeMhz = hostCpuCapacityMhz - hostCpuConsideredUsedMhz;

		var required_cpu_mhz = request_vcpu_no * hostCpuFrequencyMhz;
		var potential_cpu_used_mhz = required_cpu_mhz + hostCpuConsideredUsedMhz;
		
		if(hostCpuCapacityMhz === 0) {
			message = "hostCpuCapacityMhz is 0, cannot divide by 0";
			debug(oPlugin, message, 2, oPluginFeedback);
			addToPluginFeedbackObservations(message, oPluginFeedback);
			return -1;
		}
		
		var potential_cpu_used_ratio = (potential_cpu_used_mhz / hostCpuCapacityMhz) * 100;
		
		// Check the amount of CPU free on the host is sufficient for the requested CPU capacity
		message = "Host '" + hostName + "', hostCpuFreeMhz =  " + hostCpuFreeMhz + "', compararing to required_cpu_mhz = '" + required_cpu_mhz + "'";
		debug(oPlugin, message, 2, oPluginFeedback);
		
		if(hostCpuFreeMhz < required_cpu_mhz) {
			message = "Host '" + hostName + "' does not have sufficient capacity for running the VM";
			debug(oPlugin, message, 1, oPluginFeedback);
			addToPluginFeedbackObservations(message, oPluginFeedback);
			continue;
		}
		else {
			message = "Host '" + hostName + "' has sufficient capacity for running the VM";
			debug(oPlugin, message, 2, oPluginFeedback);
			addToPluginFeedbackObservations(message, oPluginFeedback);
		}

		// Check the CPU usage after the VM would be added would remain smaller than the CPU reserve policy
		var hostCpuFreeRatioWhatIf = 100 - potential_cpu_used_ratio;

		message = "Host '" + hostName + "', potential_cpu_used_ratio = '" + potential_cpu_used_ratio + "'";
		debug(oPlugin, message, 2, oPluginFeedback);

		message = "Host '" + hostName + "', hostCpuFreeRatioWhatIf = '" + hostCpuFreeRatioWhatIf + "'";
		debug(oPlugin, message, 2, oPluginFeedback);
		
		message = "Host '" + hostName + "', hostCpuFreeRatioWhatIf =  " + hostCpuFreeRatioWhatIf + "', comparing to target_reserve_cpu_ratio = '" + target_reserve_cpu_ratio + "'";
		debug(oPlugin, message, 2, oPluginFeedback);

		message = "Host '" + hostName + "', hostCpuFreeRatioWhatIf =  " + hostCpuFreeRatioWhatIf + "', compararing to target_reserve_cpu_ratio = '" + target_reserve_cpu_ratio + "'";
		debug(oPlugin, message, 2, oPluginFeedback);
		
		if(hostCpuFreeRatioWhatIf < target_reserve_cpu_ratio) {
			message = "The host would go beyond the CPU reserve policy if the VM would be added";
			debug(oPlugin, message, 1, oPluginFeedback);
			addToPluginFeedbackObservations(message, oPluginFeedback);
			continue;
		}
		else {
			message = "The host will have enough CPU reserve even after adding the VM";
			debug(oPlugin, message, 2, oPluginFeedback);
			addToPluginFeedbackObservations(message, oPluginFeedback);
		}
		
		// Check memory on the host
		
		var hostMemoryConsideredUsedMb = 0;
		if (hostMemoryUsedMb > hostMemoryReservedMb) {
			hostMemoryConsideredUsedMb = hostMemoryUsedMb;
		}
		else {
			hostMemoryConsideredUsedMb = hostMemoryReservedMb;
		} 
		
		message = "Host '" + hostName + "', hostMemoryUsedMb = '" + hostMemoryUsedMb + "'";
		debug(oPlugin, message, 2, oPluginFeedback);
		addToPluginFeedbackObservations(message, oPluginFeedback);
		
		message = "Host '" + hostName + "', hostMemoryReservedMb = '" + hostMemoryReservedMb + "'";
		debug(oPlugin, message, 2, oPluginFeedback);
		addToPluginFeedbackObservations(message, oPluginFeedback);
		
		message = "Host '" + hostName + "', hostMemoryConsideredUsedMb = '" + hostMemoryConsideredUsedMb + "'";
		debug(oPlugin, message, 2, oPluginFeedback);
		addToPluginFeedbackObservations(message, oPluginFeedback);
		
		var requiredMemoryMb = request_memory_gb * 1024;
		var hostMemoryUsedMbWhatIf = requiredMemoryMb + hostMemoryConsideredUsedMb;
		
		if(hostMemoryCapacityMb === 0) {
			message = "hostMemoryCapacityMb is 0, cannot divide by 0";
			debug(oPlugin, message, 2, oPluginFeedback);
			addToPluginFeedbackObservations(message, oPluginFeedback);
			return -1;
		}
		
		var hostMemoryUsedRatioWhatIf = (hostMemoryUsedMbWhatIf / hostMemoryCapacityMb) * 100;

		// Verify the current host has sufficient memory for the requested VM
		var hostMemoryFreeMb = hostMemoryCapacityMb - hostMemoryConsideredUsedMb;
		var hostMemoryFreeGb = hostMemoryFreeMb / 1024;

		message = "Host '" + hostName + "', hostMemoryFreeGb =  " + hostMemoryFreeGb + "', compararing to request_memory_gb = '" + request_memory_gb + "'";
		debug(oPlugin, message, 2, oPluginFeedback);
		
		// Verify the current host would still have sufficient reserve after the VM would be added
		if(hostMemoryFreeGb < request_memory_gb) {
			message = "Host '" + hostName + "' does not have sufficient memory for running the VM";
			debug(oPlugin, message, 1, oPluginFeedback);
			addToPluginFeedbackObservations(message, oPluginFeedback);
			continue;
		}
		else {
			message = "Host '" + hostName + "' has sufficient memory for running the VM";
			debug(oPlugin, message, 2, oPluginFeedback);
			addToPluginFeedbackObservations(message, oPluginFeedback);
		}

		// Verify the current host would still respect the memory reserve policy after the VM would be added
		var hostMemoryFreeRatioWhatIf = 100 - hostMemoryUsedRatioWhatIf;
		
		message = "Host '" + hostName + "', hostMemoryFreeRatioWhatIf =  " + hostMemoryFreeRatioWhatIf + "', compararing to target_reserve_memory_ratio = '" + target_reserve_memory_ratio + "'";
		debug(oPlugin, message, 2, oPluginFeedback);
		
		if(hostMemoryFreeRatioWhatIf < target_reserve_memory_ratio) {
			message = "The host would go beyond the memory reserve policy if the VM would be added";
			debug(oPlugin, message, 1, oPluginFeedback);
			addToPluginFeedbackObservations(message, oPluginFeedback);
			continue;
		}
		else {
			message = "The host will have enough memory reserve even after adding the VM";
			debug(oPlugin, message, 2, oPluginFeedback);
			addToPluginFeedbackObservations(message, oPluginFeedback);
		}

		// Verify the requested number of vCPUs is less or equal to the number of physical CPUs on the host
		// In theory, taking into account hyperthreading, cannot do it in Sysload		
		
		message = "For CPU and memory, the host '" + hostName + "' can run the VM";
		debug(oPlugin, message, 2, oPluginFeedback);
		addToPluginFeedbackObservations(message, oPluginFeedback);
		
		bAtLeastOneHostOkForNewVm = true;
		
		// Add the current host to the candidates
		candidateHosts.push({name:hostName, cpu:hostCpuUsedMhz});

	} // for (idxHost)

	if(bAtLeastOneHostOkForNewVm === false) {
		message = "No host could be found with enough CPU and memory";
		debug(oPlugin, message, 1, oPluginFeedback);
		addToPluginFeedbackObservations(message, oPluginFeedback);
		addToPluginFeedbackComment(message, oPluginFeedback);
		return 0;
	}
	
	message = "At least one host could be found with enough CPU and memory"
	debug(oPlugin, message, 2, oPluginFeedback);

	// Sort the candidate hosts in increasing order of CPU usage
	candidateHosts.sort(function(hostA, hostB) {
		return(hostA.cpu>hostB.cpu?1:(hostA.cpu<hostB.cpu?-1:0));
	});

	for(var candidateHost of candidateHosts) {
		message = "Host '" + candidateHost.name + "' is a candidate (CPU = '" + candidateHost.cpu + "')";
		debug(oPlugin, message, 2, oPluginFeedback);
	}
	
	// The best candidate host for running the VM is the one with the smallest CPU usage amongst the candidate ones
	message = "The best candidate host is '" + candidateHosts[0].name + "'";
	debug(oPlugin, message, 1, oPluginFeedback);
	addToPluginFeedbackObservations(message, oPluginFeedback);
	addToPluginFeedbackComment(message, oPluginFeedback);

	message = "Finished checking individual hosts for CPU and memory";
	debug(oPlugin, message, 2, oPluginFeedback);	
	
	return 1;

} // function checkHosts

// -------------------------------------------------
// Internal function for this plugin
// Check if at least one datastore is OK
// Return 1 if the answer is OK, 0 otherwise
// -------------------------------------------------
function checkDatastores(oPlugin, oMetricsData, oPluginFeedback) {

	var message = "";
	
	var request_storage_gb = oPlugin.getPluginParam ('request_storage_gb');
	message = "VM request, storage requested (GB) = '" + request_storage_gb + "'";
	debug(oPlugin, message, 1, oPluginFeedback);
	addToPluginFeedbackObservations(message, oPluginFeedback);
	
	var target_reserve_storage_ratio  = oPlugin.getPluginParam ('target_reserve_storage_ratio');
	message = "Capacity constraint, storage room for manoeuver (%) = '" + target_reserve_storage_ratio + "'";
	debug(oPlugin, message, 1, oPluginFeedback);
	addToPluginFeedbackObservations(message, oPluginFeedback);
	
	var numDatastores = oPlugin.get_MetricInst_Count (oMetricsData, "Datastore-Specific");

	if (numDatastores === 0) {
		message = "Number of given datastores is 0, bypassing the check if at least one datastore is OK";
		return 1;
	}
	
	var numDatastoresWithCapacity = 0;
	var numDatastoresWithManoeuver = 0;
	/****  PWN blocked moved into the loop for -> best practices
	var datastoreIndex = 0
	var datastoreName;
	var oDatastoreStorageFree_gb = {};
	var oDatastoreStorageCapacity_gb = {};
	*****/

	// Verify each datastore individually
	
	for(var datastoreIndex = 0; datastoreIndex < numDatastores; datastoreIndex++) {
	    var oDatastoreStorageFree_gb = {};
	    var oDatastoreStorageCapacity_gb = {};

		var datastoreName = oPlugin.get_MetricInst_Name (oMetricsData, "Datastore-Specific", datastoreIndex);
		
		message = "Checking metrics for Datastore '" + datastoreName + "'...";
		debug(oPlugin, message, 2, oPluginFeedback);

		oDatastoreStorageCapacity_gb.value  = oPlugin.get_MetricInst_Data (oMetricsData, datastoreIndex, 
			                                                                      "Datastore-Specific-storagecapacity", "avg", "valueLast");
		oDatastoreStorageCapacity_gb.pcinfo = oPlugin.get_MetricInst_Data (oMetricsData, datastoreIndex, 
			                                                                      "Datastore-Specific-storagecapacity", "avg", "infoLast");
		message = "Datastore '" + datastoreName + "', Capacity (GB) = " + oDatastoreStorageCapacity_gb.value;
		debug(oPlugin, message, 2, oPluginFeedback);
		addToPluginFeedbackObservations(message, oPluginFeedback);

		oDatastoreStorageFree_gb.value  = oPlugin.get_MetricInst_Data (oMetricsData, datastoreIndex,  
			                                                                  "Datastore-Specific-storagefree", "avg", "valueLast");
		oDatastoreStorageFree_gb.pcinfo = oPlugin.get_MetricInst_Data (oMetricsData, datastoreIndex, 
			                                                                  "Datastore-Specific-storagefree", "avg", "infoLast");
		message = "Datastore '" + datastoreName + "', Free (GB) = " + oDatastoreStorageFree_gb.value;
		debug(oPlugin, message, 2, oPluginFeedback);
		addToPluginFeedbackObservations(message, oPluginFeedback);

		// Check if the free storage is enough for the storage requested 
		if (oDatastoreStorageFree_gb.value < request_storage_gb) {
			// The current datastore does not have capacity for the VM
			message = "Datastore '" + datastoreName + "' does not have enough storage";
			debug(oPlugin, message, 1, oPluginFeedback);
			addToPluginFeedbackObservations(message, oPluginFeedback);
		}
		else {
			// The current datastore has capacity for the VM
			message = "Datastore '" + datastoreName + "' has enough storage";
			debug(oPlugin, message, 2, oPluginFeedback);
			numDatastoresWithCapacity++;
			addToPluginFeedbackObservations(message, oPluginFeedback);

			// Check room for manoeuver on storage after the VM would be added
			var datastoreUsedGbWhatIf = parseFloat(oDatastoreStorageCapacity_gb.value) - parseFloat(oDatastoreStorageFree_gb.value) + parseFloat(request_storage_gb);
			
			if(oDatastoreStorageCapacity_gb.value === 0) {
				message = "Datastore '" + datastoreName + "' has a storage capacity at 0, cannot divide by 0";
				debug(oPlugin, message, 1, oPluginFeedback);
				addToPluginFeedbackObservations(message, oPluginFeedback);
				return -1;
			}
			
			var datastoreFreeRatioWhatIf = 100 - ((datastoreUsedGbWhatIf / oDatastoreStorageCapacity_gb.value) * 100);
			message = "Datastore '" + datastoreName + "', datastoreFreeRatioWhatIf = " + datastoreFreeRatioWhatIf;
			debug(oPlugin, message, 2, oPluginFeedback);
			addToPluginFeedbackObservations(message, oPluginFeedback);

			if (datastoreFreeRatioWhatIf < target_reserve_storage_ratio) {
				message = "Datastore '" + datastoreName + "' does not have enough room for manoeuver";
				debug(oPlugin, message, 1, oPluginFeedback);
				addToPluginFeedbackObservations(message, oPluginFeedback);
			}
			else {
				message = "Datastore '" + datastoreName + "' has enough room for manoeuver";
				debug(oPlugin, message, 2, oPluginFeedback);
				addToPluginFeedbackObservations(message, oPluginFeedback);
				numDatastoresWithManoeuver++;
			}

		}

	} // for(datastoreIndex = 0; datastoreIndex < numDatastores; datastoreIndex++) {
	
	if(numDatastoresWithCapacity === 0) {
		message = "The cluster does not have enough free storage to run the VM (none of the given datastores have enough storage)";
		debug(oPlugin, message, 1, oPluginFeedback);
		addToPluginFeedbackObservations(message, oPluginFeedback);
		addToPluginFeedbackComment(message, oPluginFeedback);
		return 0;
	}

	message = "The number of datastores with enough capacity is '" + numDatastoresWithCapacity + "'"
	debug(oPlugin, message, 1, oPluginFeedback);
	
	if(numDatastoresWithManoeuver === 0) {
		message = "The cluster does not have enough storage reserve (none of the given datastores have enough reserve)";
		debug(oPlugin, message, 1, oPluginFeedback);		
		addToPluginFeedbackObservations(message, oPluginFeedback);	
		addToPluginFeedbackComment(message, oPluginFeedback);
		return 0;            
	}

	message = "The number of datastores with enough room for manoeuver is '" + numDatastoresWithManoeuver + "'"
	debug(oPlugin, message, 1, oPluginFeedback);

	message = "Finished checking individual datastores";
	debug(oPlugin, message, 2, oPluginFeedback);

	return 1;
	
} // End checkDatastores

// -------------------------------------------------
// Internal function for this plugin
// Check HA policy defined in number of hosts will be respected for CPU capacity
// Return 1 if the answer is OK, 0 otherwise
// -------------------------------------------------
function checkHAFailoverLevel(oPlugin, oMetricsData, oPluginFeedback) {
	
	var message = "";
	message = "Starting to check cluster failover policy";
	debug(oPlugin, message, 3, oPluginFeedback);
	
	/*
	// Lines below used for QA on the logical operators in the function "onGetMetricData"
	message = "TEST";
	debug(oPlugin, message, 1, oPluginFeedback);
	addToPluginFeedbackComment(message, oPluginFeedback);
	return 0;
	//return -1;
	*/
	
	var target_reserve_host_no = oPlugin.getPluginParam ('target_reserve_host_no');
	
	if(target_reserve_host_no === 0) {
		// The cluster does not have its HA reserve defined in number of hosts, no need to check
		message = "No reserve defined in number of hosts has been given, bypassing the check of the overall reserve";
		debug(oPlugin, message, 1, oPluginFeedback);
		addToPluginFeedbackObservations(message, oPluginFeedback);
		return 1;
	}
	
	message = "Given reserve in number of hosts is '" + target_reserve_host_no + "'";
	debug(oPlugin, message, 2, oPluginFeedback);
	addToPluginFeedbackObservations(message, oPluginFeedback);
	
	var message = "";
	message = "Starting to check cluster failover policy for CPU";
	debug(oPlugin, message, 3, oPluginFeedback);
	
	var request_vcpu_no = oPlugin.getPluginParam ('request_vcpu_no');

	var clusterCpuCapacityhz = oPlugin.get_OverallMetric_Data (oMetricsData, "CPU-Overall-CPUcapacity", "avg", "valueLast");
	message = "Cluster CPU capacity (MHz) is = '"+ clusterCpuCapacityhz + "'";
	debug(oPlugin, message, 2, oPluginFeedback);
	addToPluginFeedbackObservations(message, oPluginFeedback);
	
	var clusterCpuUsedMhz = oPlugin.get_OverallMetric_Data (oMetricsData, "CPU-Overall-CPUused", "avg", "valueMax");
	message = "Cluster CPU used (MHz) is = '"+ clusterCpuUsedMhz + "'";
	debug(oPlugin, message, 2, oPluginFeedback);
	addToPluginFeedbackObservations(message, oPluginFeedback);
	
	var clusterCpuFreeMhz = clusterCpuCapacityhz - clusterCpuUsedMhz;
	message = "Cluster CPU free (MHz) is = '"+ clusterCpuFreeMhz + "'";
	debug(oPlugin, message, 2, oPluginFeedback);
	
	// Verify that Free effective is at least the number of Hosts defined HA policy * the CPU capacity of hosts
	// Consider the CPU capacity is equal on each host, hence get it from the first host in the list given by the Sysload Agent
	var hostCpuCapacityMhz = oPlugin.get_MetricInst_Data (oMetricsData, 0, "Host-Specific-CPUcapacity", "avg", "valueLast");
	
	// Get CPU speed of hosts
	// Consider the CPU speed is equal on each host, hence get it from the first host in the list given by the Sysload Agent
	var hostCpuFrequencyMhz = oPlugin.get_MetricInst_Data (oMetricsData, 0, "Host-Specific-CPUspeed", "avg", "valueLast");

	// Calculate how much CPU, in MHz, the VM can consume
	var vm_cpu_consumption_mhz = request_vcpu_no * hostCpuFrequencyMhz;
	
	var clusterCPUFreePolicy = target_reserve_host_no * hostCpuCapacityMhz;
	var clusterCPUFreeWhatIf = clusterCpuFreeMhz - vm_cpu_consumption_mhz;
	
	message = "Cluster CPU to let free according to the HA policy (MHz) = '" + clusterCPUFreePolicy + "' ('" + target_reserve_host_no + "' * '" + hostCpuCapacityMhz + "')";
	debug(oPlugin, message, 2, oPluginFeedback);
	message = "Cluster CPU that would be free after the VM would be added (MHz) = '" + clusterCPUFreeWhatIf + "' ('" + clusterCpuFreeMhz + "' - '" + vm_cpu_consumption_mhz + "')";
	debug(oPlugin, message, 2, oPluginFeedback);
	addToPluginFeedbackObservations(message, oPluginFeedback);
	
	// If the capacity that must be let free is greater than what will be free after the VM will be added...
	if(clusterCPUFreeWhatIf < clusterCPUFreePolicy) {
		message = "The CPU capacity on the cluster is not sufficient according to the HA policy (given the capacity reserve of '" + target_reserve_host_no + "' host(s))";
		debug(oPlugin, message, 1, oPluginFeedback);
		addToPluginFeedbackObservations(message, oPluginFeedback);
		addToPluginFeedbackComment(message, oPluginFeedback);
		return 0;
	}
	
	message = "The CPU capacity on the cluster is sufficient according to the HA policy (given the capacity reserve of '" + target_reserve_host_no + "' host(s))";
	debug(oPlugin, message, 2, oPluginFeedback);
	addToPluginFeedbackObservations(message, oPluginFeedback);

	message = "Finished checking cluster failover policy for CPU";
	debug(oPlugin, message, 2, oPluginFeedback);

	message = "Starting to check cluster failover policy for memory";
	debug(oPlugin, message, 3, oPluginFeedback);
	
	var request_memory_gb = oPlugin.getPluginParam ('request_memory_gb');
	
	var clusterMemoryCapacityMb = parseFloat(oPlugin.get_OverallMetric_Data (oMetricsData, "Memory-Overall-memorycapacity", "avg", "valueLast"));
	var clusterMemoryConsumedMb = parseFloat(oPlugin.get_OverallMetric_Data (oMetricsData, "Memory-Overall-memoryconsumed", "avg", "valueMax"));
	var clusterMemoryFreeGb = (clusterMemoryCapacityMb - clusterMemoryConsumedMb) / 1024;
	
	// Verify that Free is at least the number of Hosts defined HA policy * the memory capacity of hosts
	// Consider the memory capacity is equal on each host, hence get it from the first host in the list given by the Sysload Agent
	var oHostMemoryCapacity = {};
	oHostMemoryCapacity.value  = oPlugin.get_MetricInst_Data (oMetricsData, 0, "Host-Specific-memorycapacity", "avg", "valueLast");
	
	var hostMemoryCapacityGb = oHostMemoryCapacity.value / 1024;
	var clusterMemoryFreeGbPolicy = target_reserve_host_no * hostMemoryCapacityGb;
	var clusterMemoryFreeGbWhatIf = clusterMemoryFreeGb - request_memory_gb;
	
	message = "Cluster memory to let free (GB) according the the HA policy = '" + clusterMemoryFreeGbPolicy + "' ('" + target_reserve_host_no + "' * '" + hostMemoryCapacityGb + "')";
	debug(oPlugin, message, 2, oPluginFeedback);
	addToPluginFeedbackObservations(message, oPluginFeedback);
	message = "Calculated cluster free memory capacity after the VM would be added = '" + clusterMemoryFreeGbWhatIf + "' ('" + clusterMemoryFreeGb + "' - '" + request_memory_gb + "')";
	debug(oPlugin, message, 2, oPluginFeedback);
	
	// Verify that the memory free effective on the cluster after the VM would be provision remains greater than the memory desired to let free by the HA level constraint
	// If the capacity that must be let free is greater than what will be free after the VM will be added...

	if(clusterMemoryFreeGbWhatIf < clusterMemoryFreeGbPolicy) {
		message = "The memory capacity on the cluster is not sufficient according to the HA policy (given the capacity reserve of '" + target_reserve_host_no + "' host(s))";
		debug(oPlugin, message, 1, oPluginFeedback);
		addToPluginFeedbackObservations(message, oPluginFeedback);
		addToPluginFeedbackComment(message, oPluginFeedback);
		return 0;
	}
	
	message = "The memory capacity on the cluster is sufficient according to the HA policy (given the capacity reserve of '" + target_reserve_host_no + "' host(s))";
	debug(oPlugin, message, 2, oPluginFeedback);
	addToPluginFeedbackObservations(message, oPluginFeedback);

	message = "Finished checking cluster failover policy for memory";
	debug(oPlugin, message, 2, oPluginFeedback);
	
	return 1;

} // checkHAFailoverLevelCPU

// -------------------------------------------------
// Log a message to the console log of Node.JS
// Function internal to this Plugin
// Example of usage: debug(oPlugin, message, 1, oPluginFeedback);
// -------------------------------------------------
function debug(oPlugin, message, messageLevel, oPluginFeedback) {

	var runTraceLevel = oPlugin.getTraceLevel();

	// Trace only if the trace level requested in the execution is greater than the trace level of the message about to be displayed
	if (runTraceLevel >= messageLevel) {
			// Print to the console
			console.log(message);
			
			if(oPluginFeedback !== null) {
				var row = {LogMessage: message};
				oPluginFeedback.oExtraInfo.log.push(row);
			}
	}
	
} // function debug

// -------------------------------------------------
// Add text to the Plugin execution comment
// Function internal to this Plugin
// -------------------------------------------------
function addToPluginFeedbackComment(message, oPluginFeedback) {
	
	if(oPluginFeedback.comment === "") {
	oPluginFeedback.comment = message;
	}
	else {
		oPluginFeedback.comment += " - " + message;
	}
	
} // function addToPluginFeedbackObservations


// -------------------------------------------------
// Add text to the analysis observations
// Function internal to this Plugin
// -------------------------------------------------
function addToPluginFeedbackObservations(message, oPluginFeedback) {
	
	var lineNumber = oPluginFeedback.oExtraInfo.observations.length + 1;
	var row = {Line: lineNumber, Observation: message};
	oPluginFeedback.oExtraInfo.observations.push(row);

	/*
	if(oExtraInfo.observations === "") {
	oExtraInfo.observations = message;
	}
	else {
		oExtraInfo.observations += " - " + message;
	}
	*/
	
} // function addToPluginFeedbackObservations
